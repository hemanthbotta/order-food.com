
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Menu</title>
<body>
<?php
  include('Header.php');
?>
      <br>
	<div class="bg2">
        <div class="content2">MENU</div>
    </div>
    <div>
        <div class="row" >
          <div class="col-sm-6">
            <div class="text3">Starters</div><br><br>
            <div class="text2">Starters are meant to be visually and gastronomically appetizing. They are served with attractive garnishes and often with a selection of salads and chutneys.</div>
          </div>
          <div class="col-sm-6">
            <img src="Images/ParadiseBiryani.jpeg" width="100%">
          </div>
        </div>
        <br><br>
        <div class="row" >
          <div class="col-sm-6">
            <img src="Images/ChickenTandooriBiryani.jpeg" width="100%">
          </div>
          <div class="col-sm-6">
          <div class="text3">Meals</div>
          <div class="text2">serves every Food lover with delicious choices of fresh cooked multiple varieties of Indian authentic veg, non-veg , biryani delicacies and sweets. </div>
          </div><br><br>
          <div class="row" >
            <div class="col-sm-6">
              <div class="text3">Curries</div><br><br>
              <div class="text2">Foodcarry choose from the wide range of options in every category the best quality. </div>
            </div>
            <div class="col-sm-6">
              <img src="Images/chickenReciepe.png" width="100%">
            </div>
          </div>
          <br><br>
        </div>
      </div>
      </div>

    <?php
      include('Footer.php');
    ?>
</body>
</html>
