<!doctype html>
<html>
    <head>

    </head>
    <body>
          <!-- Footer -->
<div style="background-color: cornsilk;">
    <footer class="page-footer font-small elegant-color">
    
        
      
        <!-- Footer Links -->
        <div class="container-fluid bg-dark text-center text-md-left pt-4 pt-md-5">
      
          <!-- Grid row -->
          <div class="row foot1 mt-1 mt-md-0 mb-4 mb-md-0">
      
            <!-- Grid column -->
            <div class="col-md-3 mx-auto mt-3 mt-md-0 mb-0 mb-md-4">
      
              <!-- Links -->
              <h5>About me</h5>
              <hr class="color-primary mb-4 mt-0 d-inline-block mx-auto w-60">
      
              <p class="foot-desc mb-0">Here you can use rows and columns to organize your footer content. Lorem
                ipsum dolor sit amet,
                consectetur
                adipisicing elit.</p>
      
            </div>
            <!-- Grid column -->
      
            <hr class="clearfix w-100 d-md-none">
      
            <!-- Grid column -->
            <div class="col-md-3 mx-auto mt-3 mt-md-0 mb-0 mb-md-4">
      
              <!-- Links -->
              <h5>Items</h5>
              <hr class="color-primary mb-4 mt-0 d-inline-block mx-auto w-60">
      
              <ul class="list-unstyled foot-desc">
                <li class="mb-2">
                  <a href="https://paradisebiryanimi.com/">Biryanis</a>
                </li>
                <li class="mb-2">
                  <a href="https://asianfoodnetwork.com/en/recipes/cuisine/chinese/paradise-fried-rice-special.html">Fried Rice</a>
                </li>
                <li class="mb-2">
                  <a href="https://order.paradisefoodcourt.in/welcome">Meals</a>
                </li>
                <li class="mb-2">
                  <a href="https://www.zomato.com/sydney/noodle-paradise-campbelltown/menu">Noodles</a>
                </li>
                <li class="mb-2">
                  <a href="https://paradiseindiancuisine.com/menu-starters.html">Starters</a>
                </li>
              </ul>
      
            </div>
            <!-- Grid column -->
      
            <hr class="clearfix w-100 d-md-none">
      
            <!-- Grid column -->
            <div class="col-md-3 mx-auto mt-3 mt-md-0 mb-0 mb-md-4">
      
              <!-- Links -->
              <h5>Useful links</h5>
              <hr class="color-primary mb-4 mt-0 d-inline-block mx-auto w-60">
      
              <ul class="list-unstyled foot-desc">
                <li class="mb-2">
                  <a href="#!">bottahemanthkumar@gmail.com</a>
                </li>
                <li class="mb-2">
                  <a href="#!">Become an Affiliate</a>
                </li>
                <li class="mb-2">
                  <a href="#!">Shipping Rates</a>
                </li>
                <li class="mb-2">
                  <a href="#!">Help</a>
                </li>
              </ul>
      
            </div>
            <!-- Grid column -->
      
            <hr class="clearfix w-100 d-md-none">
      
            <!-- Grid column -->
            <div class="col-md-3 mx-auto mt-3 mt-md-0 mb-0 mb-md-4">
      
              <!-- Links -->
              <h5>Contacts</h5>
              <hr class="color-primary mb-4 mt-0 d-inline-block mx-auto w-60">
      
              <ul class="fa-ul foot-desc ml-4">
                <li class="mb-2"><span class="fa-li"><i class="far fa-map"></i></span>GF D NO 30-15-135, 29-8-1, Waltair, Uplands, VISHAKAPATNAM :- 530020
                </li>
                <li class="mb-2"><span class="fa-li"><i class="fas fa-phone-alt"></i></span>042 876 836 908</li>
                <li class="mb-2"><span class="fa-li"><i class="far fa-envelope"></i></span>paradisefoodcourt@gmail.com</li>
                <li><span class="fa-li"><i class="far fa-clock"></i></span>Monday - Friday: 10-17</li>
              </ul>
      
            </div>
            <!-- Grid column -->
      
          </div>
          <!-- Grid row -->
      
        </div>
        <!-- Footer Links -->
      
        
        <div>
            <div class="container">
        
              <!-- Grid row-->
              <div class="row py-4 d-flex align-items-center">
        
                <!-- Grid column -->
                <div class="col-md-6 col-lg-5 text-center text-md-left mb-4 mb-md-0">
                  <h6 class="mb-0 foot1">Get connected with us on social networks!</h6>
                </div>
                <!-- Grid column -->
        
                <!-- Grid column -->
                <div class="col-md-6 col-lg-7 text-center text-md-right">
        
                  <!-- Facebook -->
                  <a class="fb-ic">
                    <i class="fab fa-facebook-f white-text mr-4"> </i>
                  </a>
                  <!-- Twitter -->
                  <a class="tw-ic">
                    <i class="fab fa-twitter white-text mr-4"> </i>
                  </a>
                  <!-- Google +-->
                  <a class="gplus-ic">
                    <i class="fab fa-google-plus-g white-text mr-4"> </i>
                  </a>
                  <!--Linkedin -->
                  <a class="li-ic">
                    <i class="fab fa-linkedin-in white-text mr-4"> </i>
                  </a>
                  <!--Instagram-->
                  <a class="ins-ic">
                    <i class="fab fa-instagram white-text"> </i>
                  </a>
        
                </div>
                <!-- Grid column -->
        
              </div>
              <!-- Grid row-->
        
            </div>
          </div>
      </footer>
      <!-- Footer -->
      <!-- Copyright -->
      <div class="footer-copyright text-center py-3">© 2021 Copyright:
        <a href="https://www.paradisefoodcourt.in/restaurants-in-vizag.html">Paradise</a> All rights reserved.
      </div>
      <!-- Copyright -->
    </div>
    </body>
</html>